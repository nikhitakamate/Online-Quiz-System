// import React from "react";

// const QuizCard = ({ quiz, onSelect }) => {
//   return (
//     <div 
//       className={`card text-white bg-${quiz.color} mb-3 shadow-lg border-0`} 
//       onClick={() => onSelect(quiz.id)} 
//       style={{ cursor: "pointer", transition: "transform 0.2s ease-in-out" }}
//     >
//       <div className="card-body">
//         <h5 className="card-title fw-bold">{quiz.title}</h5>
//         <p className="card-text mb-1"><strong>Score:</strong> {quiz.score}</p>
//         <p className="card-text"><strong>Duration:</strong> {quiz.duration} mins</p>
//       </div>
//     </div>
//   );
// };

// export default QuizCard;
